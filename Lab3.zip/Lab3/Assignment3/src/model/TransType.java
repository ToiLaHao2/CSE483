package model;

public enum TransType {
    DEPOSIT, WITHDRAWAL;
}
