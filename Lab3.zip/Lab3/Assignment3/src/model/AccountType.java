package model;

public enum AccountType {
    SAVINGS, CHECKING, LOAN;
}
