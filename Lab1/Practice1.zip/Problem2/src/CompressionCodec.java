public class CompressionCodec {
    public void GZip() {
        System.out.println("Compression by Gzip");
    }

    public void BZip2() {
        System.out.println("Compression by Bzip2");
    }
}
