public class Menu {
    public Menu() {

    }

    public void showMenu() {
        System.out.println("Menu");
        System.out.println("1. Compress with GZip");
        System.out.println("2. Compress with BZip2");
        System.out.println("3. Encrypt with AES");
        System.out.println("4. Encrypt with DES");
        System.out.println("5. Write file to CSV");
        System.out.println("6. Write file to JSON");
        System.out.println("7. Write file to XML");
    }
}
