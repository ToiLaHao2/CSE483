public class EncryptionCodec {
    public void AESEncrypt() {
        System.out.println("AES Encrypt");
    }

    public void DESEncrypt() {
        System.out.println("DES Encrypt");
    }
}
