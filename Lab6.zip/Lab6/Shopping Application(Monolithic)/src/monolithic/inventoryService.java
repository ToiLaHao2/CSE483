package monolithic;

public class inventoryService {
    
}
