package monolithic;

public class notificationService {
    
}
